package com.guru99.bank.pruebas.stepdefinitions;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.guru99.bank.pruebas.pages.HomeGuru99POM;
import com.guru99.bank.pruebas.stepdefinitions.Hook;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LogInStepDefinitions {
	
	WebDriver driver ;
	HomeGuru99POM home;
	Hook hook=new Hook();
	
	@Given("I want to Login into Demo Guru")
	public void iWantToLoginIntoDemoGuru() {
		hook.setUp();
		driver=Hook.driver;
		home=new HomeGuru99POM(driver);
	    driver.manage().window().maximize();
		driver.get("http://demo.guru99.com/V4/index.php");
	}

	@When("I enter username and password")
	public void iEnterUsernameAndPassword(io.cucumber.datatable.DataTable dataTable) {
		List<String> dataList=dataTable.asList();
		home.writeUser(dataList.get(0));
		home.writePassword(dataList.get(1));
		home.clickLogin();
	}

	@Then("I should see Welcome To Managers Page of Guru99 Bank text")
	public void iShouldSeeWelcomeToManagersPageOfGuru99BankText() {
		
		 home.validateWelcome();
		   driver.quit();
	}
}
