package com.guru99.bank.pruebas.stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Hook {

	static WebDriver driver;

	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\\\MiPimerSelenium1\\\\chromedriver.exe");
		driver = new ChromeDriver();
	}


}
