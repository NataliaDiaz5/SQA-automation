package com.guru99.bank.pruebas.stepdefinitions;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.guru99.bank.pruebas.pages.NewCustomerPOM;
import com.guru99.bank.pruebas.stepdefinitions.Hook;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NewCustomerDefinitions {
	WebDriver driver;
	NewCustomerPOM customer;

	@When("I create a new customer")
	public void iCreateANewCustomer(io.cucumber.datatable.DataTable dataTable) {
		driver = Hook.driver;
	  	customer = new NewCustomerPOM(driver);
	  	customer.ClickNewCustomer();
		List<String> dataList=dataTable.asList();
		customer.writeCustomerName(dataList.get(0));
		customer.clickGender();
		customer.writeDateOfBirth(dataList.get(1));
		customer.writeAddress(dataList.get(2));
		customer.writeCity(dataList.get(3));
		customer.writeState(dataList.get(4));
		customer.writePIN(dataList.get(5));
		customer.writeMobileNumber(dataList.get(6));
		customer.writeEmail(dataList.get(7));
		customer.writePassword(dataList.get(8));
		customer.clickInSubmit();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("I show message Customer Registered Successfully")
	public void iShowMessageCustomerRegisteredSuccessfully() {
		customer.validateNewCustomer();
		driver.quit();
	}
}
