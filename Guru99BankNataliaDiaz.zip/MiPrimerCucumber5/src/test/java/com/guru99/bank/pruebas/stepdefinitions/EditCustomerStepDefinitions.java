package com.guru99.bank.pruebas.stepdefinitions;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.guru99.bank.pruebas.pages.EditCustomerPOM;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditCustomerStepDefinitions {
	WebDriver driver;
	EditCustomerPOM customer;

	@When("I edit a Customer")
	
	public void iCreateANewCustomer(io.cucumber.datatable.DataTable dataTable) {
		driver = Hook.driver;
	  	customer = new EditCustomerPOM(driver);
	  	customer.ClickEditCustomer();
		List<String> dataList=dataTable.asList();
		customer.writeCustomerID(dataList.get(0));		
		customer.clickInSubmit();
		customer.writeAddress(dataList.get(1));
		customer.clickInSubmitSent();
	
	}

	@Then("the user should be edited")
	public void iShowMessageCustomerEdited() {
    customer.validateEdition();
    try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		driver.quit();
	}

	




}
