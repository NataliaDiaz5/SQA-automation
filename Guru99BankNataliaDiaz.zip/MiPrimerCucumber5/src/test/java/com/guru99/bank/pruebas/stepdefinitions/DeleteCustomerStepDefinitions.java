package com.guru99.bank.pruebas.stepdefinitions;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.guru99.bank.pruebas.pages.DeleteCustomerPOM;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteCustomerStepDefinitions {

		WebDriver driver;
		DeleteCustomerPOM customer;
		
		@When("I delete a Customer")
		
		public void iCreateANewCustomer(io.cucumber.datatable.DataTable dataTable) {
				driver = Hook.driver;
			  	customer = new DeleteCustomerPOM(driver);
			  	customer.ClickEliminarCustomer();
				List<String> dataList=dataTable.asList();
				customer.writeCustomerID(dataList.get(0));		
				customer.clickInSubmit();
			    customer.Alert();
				
				
		}
		@Then("the user should be deleted")
		public void the_user_should_be_deleted() {
		 
			driver.quit();
		}
		}


