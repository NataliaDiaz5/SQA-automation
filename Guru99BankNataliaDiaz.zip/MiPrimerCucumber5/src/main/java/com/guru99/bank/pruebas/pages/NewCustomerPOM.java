package com.guru99.bank.pruebas.pages;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustomerPOM {
	WebDriver driver;
	By btnNewCustomer = By.xpath("//a[@href='addcustomerpage.php']");
	By txtCustomerName = By.name("name");
	By radiobtnGender = By.xpath("//input[@value='f']");
	By txtDateOfBirth = By.name("dob");
	By txtAddress=By.name("addr");
	By txtCity=By.name("city");
	By txtState=By.name("state");
	By txtPIN=By.name("pinno");
	By txtMobileNumber=By.name("telephoneno");
	By txtEmail=By.name("emailid");
	By txtPassword=By.name("password");
	By btnSubmit=By.name("sub");
	By txtCustomerRegistred = By.xpath("//p[text()='Customer Registered Successfully!!!']");
	
	public NewCustomerPOM(WebDriver driver) {
		this.driver = driver;
	}
	public void ClickNewCustomer () {
		driver.findElement(btnNewCustomer).click();
	}
	public void writeCustomerName(String CustomerName) {
		driver.findElement(txtCustomerName).sendKeys(CustomerName);
	}
	public void clickGender () {
		driver.findElement(radiobtnGender).click();
	}
	public void writeDateOfBirth(String DateOfBirthday) {
		driver.findElement(txtDateOfBirth).sendKeys(DateOfBirthday);
	}
	
	public void writeAddress(String Address) {
		driver.findElement(txtAddress).sendKeys(Address);
	}
	
	public void writeCity(String City) {
		driver.findElement(txtCity).sendKeys(City);
	}
	
	public void writeState(String State) {
		driver.findElement(txtState).sendKeys(State);
	}
	
	public void writePIN(String PIN) {
		driver.findElement(txtPIN).sendKeys(PIN);
	}
	
	public void writeMobileNumber(String MobileNumber) {
		driver.findElement(txtMobileNumber).sendKeys(MobileNumber);
	}
	
	public void writeEmail(String Email) {
		driver.findElement(txtEmail).sendKeys(Email);
	}
	
	public void writePassword(String Password) {
		driver.findElement(txtPassword).sendKeys(Password);
	}
	public void clickInSubmit() {
		driver.findElement(btnSubmit).click();
	}

	public void validateNewCustomer() {
		assertThat(driver.findElement(txtCustomerRegistred).isDisplayed(), Matchers.is(true));
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
