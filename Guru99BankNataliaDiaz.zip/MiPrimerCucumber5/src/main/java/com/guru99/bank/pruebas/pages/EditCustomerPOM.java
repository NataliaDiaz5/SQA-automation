package com.guru99.bank.pruebas.pages;

import static org.junit.Assert.assertThat;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EditCustomerPOM {
	WebDriver driver;
	By btnEditarCustomer = By.xpath("//a[@href='EditCustomer.php']");
	By txtmCustomerID = By.name("cusid");
	By btnSubmit=By.name("AccSubmit");
	By txtAddress=By.name("addr");
	By txtCustomerEdited = By.xpath("//p[text()='Customer details updated Successfully!!!']");
	By btnSubmitSent=By.name("sub");
	
public EditCustomerPOM(WebDriver driver) {
	this.driver = driver;
}
public void ClickEditCustomer () {
	driver.findElement(btnEditarCustomer).click();
}
public void writeCustomerID(String CustomerID) {
	driver.findElement(txtmCustomerID).sendKeys(CustomerID);
}

public void clickInSubmit() {
	driver.findElement(btnSubmit).click();
}

public void validateEdition() {
	assertThat(driver.findElement(txtCustomerEdited).isDisplayed(), Matchers.is(true));

try {
	Thread.sleep(3000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
public void writeAddress(String Address) {
	driver.findElement(txtAddress).clear();
	driver.findElement(txtAddress).sendKeys(Address);
	

} 

public void clickInSubmitSent() {
	driver.findElement(btnSubmitSent).click();

	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}

