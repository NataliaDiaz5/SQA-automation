package com.guru99.bank.pruebas.pages;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DeleteCustomerPOM {
	WebDriver driver;
	By btnEliminarCustomer = By.xpath("//a[@href='DeleteCustomerInput.php']");
	By txtmCustomerID = By.name("cusid");
	By btnSubmit=By.name("AccSubmit");
	By txtCustomerDeleted = By.xpath("//p[text()='Customer details updated Successfully!!!']");
	
	//voy a declarar los metodos que se van a utilizar en el stepDefinitions
	public DeleteCustomerPOM(WebDriver driver) {
		this.driver = driver;
	}
	public void ClickEliminarCustomer () {
		driver.findElement(btnEliminarCustomer).click();
	}
	public void writeCustomerID(String CustomerID) {
		driver.findElement(txtmCustomerID).sendKeys(CustomerID);
	}

	public void clickInSubmit() {
		driver.findElement(btnSubmit).click();
	
	}
public void Alert() {
	driver.switchTo().alert().accept();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


	public void validateDelete() {
	assertThat(driver.findElement(txtCustomerDeleted).isDisplayed(), Matchers.is(true));
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	}	
	


	

