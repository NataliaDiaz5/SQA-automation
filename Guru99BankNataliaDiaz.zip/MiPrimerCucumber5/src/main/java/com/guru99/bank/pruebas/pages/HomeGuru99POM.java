package com.guru99.bank.pruebas.pages;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomeGuru99POM {
	WebDriver driver;
	By txtUsername=By.name("uid");
	By txtPassword=By.name("password");
	By btnLogin=By.name("btnLogin");
   By welcomeText = By.xpath("//td[text()='Manger Id : mngr259854']");
	
	public HomeGuru99POM (WebDriver driver ) {
		this.driver = driver;
		
	}
	public void writeUser(String username) {
		driver.findElement(txtUsername).sendKeys(username);		
	}
	
	public void writePassword(String password) {
		driver.findElement(txtPassword).sendKeys(password);
	}
	
	public void clickLogin() {
		driver.findElement(btnLogin).click();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

public void validateWelcome() {
	assertThat(driver.findElement(welcomeText).isDisplayed(), Matchers.is(true));
	}

}